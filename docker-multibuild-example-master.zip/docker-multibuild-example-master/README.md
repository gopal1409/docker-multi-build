# docker-multibuild-example
This is an demonstration project for docker multi build concept
